export type TextAlign =
  | 'initial'
  | 'left'
  | 'center'
  | 'right'
  | 'justify'
  | 'justify-left'
  | 'justify-center'
  | 'justify-right';
