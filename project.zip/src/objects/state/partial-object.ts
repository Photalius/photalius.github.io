export interface PartialObject {
  name: string;
  id: string;
  selectable: boolean;
}
