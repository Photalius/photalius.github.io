export const defaultObjectProps = {
  fill: '#1565C0',
  opacity: 1,
  backgroundColor: null,
  strokeWidth: 0.05,
  stroke: '#000',
};
