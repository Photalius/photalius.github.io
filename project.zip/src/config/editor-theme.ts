export enum EditorTheme {
  DARK = 'dark',
  LIGHT = 'light',
}
