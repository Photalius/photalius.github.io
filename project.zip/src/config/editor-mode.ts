export enum EditorMode {
  INLINE = 'inline',
  OVERLAY = 'overlay',
}
