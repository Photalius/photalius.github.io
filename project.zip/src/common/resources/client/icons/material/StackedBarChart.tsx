import {createSvgIcon} from '../create-svg-icon';

export const StackedBarChartIcon = createSvgIcon(
  <path d="M6 10h3v10H6V10zm0-5h3v4H6V5zm10 11h3v4h-3v-4zm0-3h3v2h-3v-2zm-5 0h3v7h-3v-7zm0-4h3v3h-3V9z" />
, 'StackedBarChartOutlined');
