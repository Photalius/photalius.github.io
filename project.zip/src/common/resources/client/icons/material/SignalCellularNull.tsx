import {createSvgIcon} from '../create-svg-icon';

export const SignalCellularNullIcon = createSvgIcon(
  <path d="M20 6.83V20H6.83L20 6.83M22 2 2 22h20V2z" />
, 'SignalCellularNullOutlined');
