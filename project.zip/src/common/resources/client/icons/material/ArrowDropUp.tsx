import {createSvgIcon} from '../create-svg-icon';

export const ArrowDropUpIcon = createSvgIcon(
  <path d="m7 14 5-5 5 5H7z" />
, 'ArrowDropUpOutlined');
