import {createSvgIcon} from '../create-svg-icon';

export const SignalCellular4BarIcon = createSvgIcon(
  <path d="M2 22h20V2L2 22z" />
, 'SignalCellular4BarOutlined');
