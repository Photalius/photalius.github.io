/// <reference types="vite/client" />

declare module 'style-inject' {
  export default function styleInject(css: string): void;
}
