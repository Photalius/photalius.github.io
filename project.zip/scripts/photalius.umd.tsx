import {Photalius} from '../src/photalius';

export default Photalius;
